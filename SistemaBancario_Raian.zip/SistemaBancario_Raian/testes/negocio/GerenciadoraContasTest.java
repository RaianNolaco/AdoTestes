package negocio;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class GerenciadoraContasTest {
	private GerenciadoraContas gerContas;
	
	@Test
	public void testTransfereValor() {
		int id1 = 1;
		int id2 = 2;
		
		ContaCorrente conta1 = new ContaCorrente(id1,200,true);
		ContaCorrente conta2 = new ContaCorrente(id2,0,true);
		
		List<ContaCorrente> contasDoBanco = new ArrayList<>();
		contasDoBanco.add(conta1);
		contasDoBanco.add(conta2);
		
		gerContas = new GerenciadoraContas(contasDoBanco);
		
		boolean sucesso = gerContas.transfereValor(id1, 100, id2);
		
		assertTrue(sucesso);
		assertThat(conta1.getSaldo(), is(100.0));
		assertThat(conta1.getSaldo(), is(100.0));
	}
	
	@Test
	public void testTransfereValorUm() {
		int idConta01 = 1;
		int idConta02 = 1;

		ContaCorrente conta01 = new ContaCorrente(idConta01, 200, true);
		ContaCorrente conta02 = new ContaCorrente(idConta02, 0, true);

		
		
		List<ContaCorrente> contasDoBanco = new ArrayList<>();
		
		contasDoBanco.add(conta01);
		contasDoBanco.add(conta02);
		
		gerContas = new GerenciadoraContas(contasDoBanco);
	
		boolean sucesso = gerContas.transfereValor(idConta01, 100, idConta02);
		
		assertTrue(sucesso);
		assertThat(conta01.getSaldo(), equalTo(100.0));
		assertThat(conta02.getSaldo(), equalTo(100.0));
	}
	
	

	@Test
	public void testTransfereValorDois() {
		int id1 = 1;
		int id2 = 1;

		ContaCorrente conta1 = new ContaCorrente(id1, 100, true);
		ContaCorrente conta2 = new ContaCorrente(id2, 0, true);
		
		List<ContaCorrente> contasDoBanco = new ArrayList<>();
		
		contasDoBanco.add(conta1);
		contasDoBanco.add(conta2);
		
		gerContas = new GerenciadoraContas(contasDoBanco);
	
		boolean sucesso = gerContas.transfereValor(id1, 200, id2);
		
		assertTrue(sucesso);
		assertThat(conta1.getSaldo(), equalTo(-100.0));
		assertThat(conta2.getSaldo(), equalTo(200.0));
	}
	
	@Test
	public void testTransfereValorTres() {
		int id1 = 1;
		int id2 = 1;

		ContaCorrente conta1 = new ContaCorrente(id1, -100, true);
		ContaCorrente conta2 = new ContaCorrente(id2, 0, true);
		
		List<ContaCorrente> contasDoBanco = new ArrayList<>();
		
		contasDoBanco.add(conta1);
		contasDoBanco.add(conta2);
		
		gerContas = new GerenciadoraContas(contasDoBanco);
	
		boolean sucesso = gerContas.transfereValor(id1, 100, id2);
		
		assertTrue(sucesso);
		assertThat(conta1.getSaldo(), equalTo(-100.0));
		assertThat(conta2.getSaldo(), equalTo(200.0));
	}	
	
	
	
	@Test
	public void testTransfereValorQuatro() {
		int id1 = 1;
		int id2 = 1;

		ContaCorrente conta1 = new ContaCorrente(id1, -100, true);
		ContaCorrente conta2 = new ContaCorrente(id2, -100, true);
		
		List<ContaCorrente> contasDoBanco = new ArrayList<>();
		
		contasDoBanco.add(conta1);
		contasDoBanco.add(conta2);
		
		gerContas = new GerenciadoraContas(contasDoBanco);
	
		boolean sucesso = gerContas.transfereValor(id1, 200, id2);
		
		assertTrue(sucesso);
		assertThat(conta1.getSaldo(), equalTo(-300.0));
		assertThat(conta2.getSaldo(), equalTo(100.0));
	}	

	
}
