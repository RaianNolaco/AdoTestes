package negocio;

import static org.junit.Assert.*;

import static org.hamcrest.CoreMatchers.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;

public class GerenciadoraClientesTest {
	private GerenciadoraClientes gerCli;
	private int idCliente1 = 1;
	private int idCliente2 = 2;
	
	@Rule
    public ExpectedException thrown = ExpectedException.none();
		
	@Before
	public void setUp() {
		Cliente cliente1 = new Cliente(idCliente1,"João",31,"joao@gmail.com",1,true);
		Cliente cliente2 = new Cliente(idCliente2,"Maria",34,"maria@gmail.com",1,true);
	 
		
		List<Cliente> clientesDoBanco = new ArrayList<>();
		clientesDoBanco.add(cliente1);
		clientesDoBanco.add(cliente2);
		
		gerCli = new GerenciadoraClientes(clientesDoBanco);
		
	}
	
	@After
	public void tearDown() {
		gerCli.limpa();
	}
	
	@Test
	public void testPesquisaCliente() {
		Cliente cliente = gerCli.pesquisaCliente(idCliente1);
		
		assertThat(cliente.getId(),is(idCliente1));
	}
	
	@Test
	public void testRemoveCliente() {
		boolean remocaoCliente = gerCli.removeCliente(idCliente2);
		
		assertThat(remocaoCliente, is(true));
		assertThat(gerCli.getClientesDoBanco().size(), is(1));
		assertNull(gerCli.pesquisaCliente(idCliente2));
		
	}

	@Test
	public void testIdadeIdealCliente() throws IdadeNaoPermitidaException {
		Cliente clienteIdeal = new Cliente(1,"Mauro",49,"Mauro@yahoo.com",1,true);								
		assertTrue(gerCli.validaIdade(clienteIdeal.getIdade()));
	}
	
	@Test(expected=IdadeNaoPermitidaException.class)
	public void testIdadeAlta() throws IdadeNaoPermitidaException{
		Cliente clienteMaior = new Cliente(1,"guilhermina",66,"",1,true);
	    gerCli.validaIdade(clienteMaior.getIdade());
	}
	
	
	
	@Test(expected=IdadeNaoPermitidaException.class)
	public void testIdadeBaixa() throws IdadeNaoPermitidaException{
		Cliente clienteMenor = new Cliente(1,"Joãozinho",17,"joaozin@gmail.com",1,true);
	    gerCli.validaIdade(clienteMenor.getIdade());
	}
	
	@Test
	public void validarIdateEquivalenciaDentro() throws IdadeNaoPermitidaException {
			boolean validacao = gerCli.validaIdade(18);
			assertTrue(validacao);
	}

	@Test(expected=IdadeNaoPermitidaException.class)
	public void validarIdateEquivalenciaSuperioDois() throws IdadeNaoPermitidaException {
			boolean validacao = gerCli.validaIdade(66);
			assertTrue(validacao);
	}

	@Test
	public void validarIdateLimiteDentroInferior() throws IdadeNaoPermitidaException {
			boolean validacao = gerCli.validaIdade(18);
			assertTrue(validacao);
	}

	@Test
	public void validarIdateLimiteDentroSuperior() throws IdadeNaoPermitidaException {
			boolean validacao = gerCli.validaIdade(65);
			assertTrue(validacao);
	}
	
}
